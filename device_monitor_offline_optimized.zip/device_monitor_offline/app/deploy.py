#!/usr/bin/env python3
"""
部署脚本
用于将应用部署到生产环境
"""
import os
import sys
import shutil
import subprocess
import time

def check_requirements():
    """检查部署要求"""
    print("检查部署要求...")
    
    # 检查requirements.txt是否存在
    if not os.path.exists("requirements.txt"):
        print("生成requirements.txt...")
        subprocess.run([sys.executable, "-m", "pip", "freeze"], stdout=open("requirements.txt", "w"), check=True)
    
    # 检查必要文件
    required_files = [
        "src/main.py",
        "src/static/index.html",
        "src/static/css/styles.css",
        "src/static/js/app.js",
        "src/static/js/echarts.min.js",
        "start.py"
    ]
    
    missing_files = []
    for file_path in required_files:
        if not os.path.exists(file_path):
            missing_files.append(file_path)
    
    if missing_files:
        print("错误: 缺少以下必要文件:")
        for file_path in missing_files:
            print(f"  - {file_path}")
        return False
    
    print("部署要求检查通过")
    return True

def prepare_deployment_package():
    """准备部署包"""
    print("准备部署包...")
    
    # 创建部署目录
    deploy_dir = "deploy"
    if os.path.exists(deploy_dir):
        shutil.rmtree(deploy_dir)
    os.makedirs(deploy_dir)
    
    # 复制必要文件
    dirs_to_copy = ["src", "venv"]
    files_to_copy = ["requirements.txt", "start.py"]
    
    for dir_name in dirs_to_copy:
        if os.path.exists(dir_name):
            shutil.copytree(dir_name, os.path.join(deploy_dir, dir_name))
    
    for file_name in files_to_copy:
        if os.path.exists(file_name):
            shutil.copy2(file_name, os.path.join(deploy_dir, file_name))
    
    print(f"部署包已准备完成: {deploy_dir}/")
    return deploy_dir

def deploy_to_production(deploy_dir):
    """部署到生产环境"""
    print("正在部署到生产环境...")
    
    try:
        # 使用deploy_apply_deployment工具部署
        from deploy_apply_deployment import deploy_flask_app
        result = deploy_flask_app(deploy_dir)
        
        if result and result.get("url"):
            print(f"部署成功! 应用已部署到: {result['url']}")
            return result["url"]
        else:
            print("部署失败，未能获取部署URL")
            return None
    except Exception as e:
        print(f"部署过程中出错: {e}")
        return None

def main():
    """主函数"""
    print("=== 局域网设备智能监控可视化大屏部署工具 ===")
    
    # 检查部署要求
    if not check_requirements():
        print("部署要求检查失败，中止部署")
        return
    
    # 准备部署包
    deploy_dir = prepare_deployment_package()
    
    # 部署到生产环境
    deploy_url = deploy_to_production(deploy_dir)
    
    if deploy_url:
        print("\n部署完成!")
        print(f"应用已部署到: {deploy_url}")
        print("您可以通过上述URL访问应用")
    else:
        print("\n部署失败!")
        print("请检查错误信息并重试")

if __name__ == "__main__":
    main()
