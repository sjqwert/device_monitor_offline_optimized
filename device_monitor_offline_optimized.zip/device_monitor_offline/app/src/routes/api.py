from flask import Blueprint, jsonify, request
from datetime import datetime, timedelta
from src.models.device import Device, db
from src.services.influxdb_service import get_device_history

# 创建蓝图
api_bp = Blueprint('api', __name__)

@api_bp.route('/devices', methods=['GET'])
def get_devices():
    """获取所有设备的基本信息和最新状态"""
    try:
        # 从数据库获取设备基本信息
        devices = Device.query.all()
        
        # 获取设备最新状态（从内存缓存）
        from src.services.mqtt_service import get_all_device_status
        device_status = get_all_device_status()
        
        # 合并设备信息和最新状态
        result = []
        for device in devices:
            device_dict = device.to_dict()
            ip_address = device.ip_address
            
            if ip_address in device_status:
                device_dict['status'] = device_status[ip_address]
                # 检查设备是否在线（最后在线时间在5分钟内）
                if device.last_seen_at:
                    device_dict['online'] = (datetime.utcnow() - device.last_seen_at) < timedelta(minutes=5)
                else:
                    device_dict['online'] = False
            else:
                device_dict['status'] = None
                device_dict['online'] = False
            
            result.append(device_dict)
        
        return jsonify({"devices": result})
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@api_bp.route('/devices/<device_id>/history', methods=['GET'])
def get_device_history_api(device_id):
    """获取设备历史数据"""
    try:
        param = request.args.get('param', 'temperature')
        start_time = request.args.get('start_time')
        end_time = request.args.get('end_time')
        
        if not start_time or not end_time:
            return jsonify({"error": "Missing start_time or end_time parameter"}), 400
        
        # 查询历史数据
        data_points = get_device_history(device_id, param, start_time, end_time)
        
        return jsonify({
            "device_id": device_id,
            "param": param,
            "start_time": start_time,
            "end_time": end_time,
            "data": data_points
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@api_bp.route('/status', methods=['GET'])
def get_system_status():
    """获取系统整体状态"""
    try:
        # 获取总设备数
        total_devices = Device.query.count()
        
        # 获取在线设备数（最后在线时间在5分钟内）
        five_min_ago = datetime.utcnow() - timedelta(minutes=5)
        online_devices = Device.query.filter(Device.last_seen_at > five_min_ago).count()
        
        # 获取设备最新状态
        from src.services.mqtt_service import get_all_device_status
        device_status = get_all_device_status()
        
        # 计算告警设备数
        alert_devices = 0
        for status in device_status.values():
            if status.get('alerts') and len(status['alerts']) > 0:
                alert_devices += 1
        
        return jsonify({
            "total_devices": total_devices,
            "online_devices": online_devices,
            "alert_devices": alert_devices,
            "system_time": datetime.utcnow().isoformat()
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
