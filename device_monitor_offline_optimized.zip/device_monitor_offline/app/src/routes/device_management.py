from flask import Blueprint, jsonify, request
from src.models.device import Device, db
from datetime import datetime

# 创建蓝图
device_bp = Blueprint('device', __name__)

@device_bp.route('/devices', methods=['POST'])
def add_device():
    """添加新设备"""
    try:
        data = request.json
        
        # 验证必要字段
        if not data or 'ip_address' not in data or 'name' not in data:
            return jsonify({"error": "缺少必要字段: ip_address, name"}), 400
        
        ip_address = data['ip_address']
        name = data['name']
        
        # 检查IP地址格式
        ip_parts = ip_address.split('.')
        if len(ip_parts) != 4:
            return jsonify({"error": "IP地址格式无效"}), 400
        
        for part in ip_parts:
            try:
                num = int(part)
                if num < 0 or num > 255:
                    return jsonify({"error": "IP地址格式无效"}), 400
            except ValueError:
                return jsonify({"error": "IP地址格式无效"}), 400
        
        # 检查设备是否已存在
        existing_device = Device.query.filter_by(ip_address=ip_address).first()
        if existing_device:
            return jsonify({"error": f"设备IP {ip_address} 已存在"}), 409
        
        # 创建新设备
        location = data.get('location', '')
        device_type = data.get('type', '')
        status_thresholds = data.get('status_thresholds', {})
        
        new_device = Device(
            ip_address=ip_address,
            name=name,
            location=location,
            type=device_type,
            status_thresholds=status_thresholds
        )
        
        db.session.add(new_device)
        db.session.commit()
        
        return jsonify({
            "message": "设备添加成功",
            "device": new_device.to_dict()
        }), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": f"添加设备时出错: {str(e)}"}), 500

@device_bp.route('/devices/<device_ip>', methods=['DELETE'])
def remove_device(device_ip):
    """删除设备"""
    try:
        # 查找设备
        device = Device.query.filter_by(ip_address=device_ip).first()
        
        if not device:
            return jsonify({"error": f"设备IP {device_ip} 不存在"}), 404
        
        # 删除设备
        db.session.delete(device)
        db.session.commit()
        
        return jsonify({
            "message": f"设备 {device_ip} 已成功删除"
        }), 200
    
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": f"删除设备时出错: {str(e)}"}), 500
