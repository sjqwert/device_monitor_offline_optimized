import asyncio
import json
import threading
from flask import Blueprint, request
import websockets

from src.services.mqtt_service import register_callback, unregister_callback, get_all_device_status

# 创建蓝图
ws_bp = Blueprint('websocket', __name__)

# 存储所有WebSocket连接
connected_clients = set()
# 线程锁，用于保护connected_clients的并发访问
clients_lock = threading.Lock()

async def handle_client(websocket, path):
    """处理WebSocket客户端连接"""
    # 注册新客户端
    with clients_lock:
        connected_clients.add(websocket)
    
    print(f"新的WebSocket客户端连接: {websocket.remote_address}")
    
    try:
        # 发送当前所有设备状态
        all_status = get_all_device_status()
        if all_status:
            await websocket.send(json.dumps({
                "type": "init",
                "data": list(all_status.values())
            }))
        
        # 保持连接，等待客户端消息
        async for message in websocket:
            try:
                data = json.loads(message)
                # 处理客户端消息（如果有需要）
                print(f"收到客户端消息: {data}")
                
                # 这里可以添加对客户端消息的处理逻辑
                
            except json.JSONDecodeError:
                print(f"无效的JSON格式: {message}")
    
    except websockets.exceptions.ConnectionClosed:
        print(f"WebSocket连接关闭: {websocket.remote_address}")
    finally:
        # 移除断开的客户端
        with clients_lock:
            connected_clients.remove(websocket)

async def broadcast_message(message):
    """向所有连接的客户端广播消息"""
    if not connected_clients:
        return
    
    # 将消息转换为JSON字符串
    message_str = json.dumps(message)
    
    # 创建发送任务列表
    with clients_lock:
        tasks = [client.send(message_str) for client in connected_clients]
    
    # 并发发送消息
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)

def mqtt_callback(data):
    """MQTT回调函数，接收新数据并广播给WebSocket客户端"""
    # 创建一个新的事件循环来运行异步广播函数
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    try:
        loop.run_until_complete(broadcast_message(data))
    finally:
        loop.close()

# WebSocket服务器实例
websocket_server = None
# MQTT回调ID
mqtt_callback_id = None

def start_websocket_server(host='0.0.0.0', port=8765):
    """启动WebSocket服务器"""
    global websocket_server, mqtt_callback_id
    
    # 注册MQTT回调
    mqtt_callback_id = register_callback(mqtt_callback)
    
    # 启动WebSocket服务器
    start_server = websockets.serve(handle_client, host, port)
    
    # 获取当前事件循环
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    # 启动服务器
    websocket_server = loop.run_until_complete(start_server)
    print(f"WebSocket服务器已启动，监听 {host}:{port}")
    
    # 运行事件循环
    threading.Thread(target=loop.run_forever, daemon=True).start()
    
    return websocket_server

def stop_websocket_server():
    """停止WebSocket服务器"""
    global websocket_server, mqtt_callback_id
    
    if websocket_server:
        websocket_server.close()
        print("WebSocket服务器已关闭")
    
    # 注销MQTT回调
    if mqtt_callback_id is not None:
        unregister_callback(mqtt_callback_id)

def init_websocket_service(app):
    """初始化WebSocket服务"""
    # 获取配置
    host = '0.0.0.0'
    port = 8765
    
    # 启动WebSocket服务器
    server = start_websocket_server(host, port)
    
    # 注册关闭回调
    @app.teardown_appcontext
    def shutdown_websocket(exception=None):
        stop_websocket_server()
    
    return server
