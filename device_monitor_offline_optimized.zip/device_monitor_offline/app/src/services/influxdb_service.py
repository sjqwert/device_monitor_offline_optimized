from datetime import datetime
from influxdb_client import InfluxDBClient

# InfluxDB配置
INFLUX_URL = "http://localhost:8086"
INFLUX_TOKEN = "my-token"
INFLUX_ORG = "my-org"
INFLUX_BUCKET = "device_data"

def get_device_history(device_id, param, start_time, end_time):
    """获取设备历史数据"""
    try:
        # 连接InfluxDB
        client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
        query_api = client.query_api()
        
        # 构建Flux查询
        query = f'''
        from(bucket: "{INFLUX_BUCKET}")
            |> range(start: {start_time}, stop: {end_time})
            |> filter(fn: (r) => r._measurement == "device_data")
            |> filter(fn: (r) => r.ip_address == "{device_id}")
            |> filter(fn: (r) => r._field == "{param}")
            |> sort(columns: ["_time"])
        '''
        
        # 执行查询
        result = query_api.query(query=query)
        
        # 处理结果
        data_points = []
        for table in result:
            for record in table.records:
                data_points.append({
                    "time": record.get_time().isoformat(),
                    "value": record.get_value()
                })
        
        client.close()
        
        return data_points
    
    except Exception as e:
        print(f"获取历史数据失败: {e}")
        return []

def save_to_influxdb(ip_address, params, timestamp=None):
    """将设备数据保存到InfluxDB"""
    try:
        if timestamp is None:
            timestamp = datetime.utcnow().isoformat()
            
        client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
        write_api = client.write_api()
        
        # 构建数据点
        point = {
            "measurement": "device_data",
            "tags": {
                "ip_address": ip_address
            },
            "time": timestamp,
            "fields": {}
        }
        
        # 添加所有参数作为字段
        for key, value in params.items():
            if isinstance(value, (int, float)):
                point["fields"][key] = value
            else:
                point["fields"][key] = str(value)
        
        # 写入数据
        write_api.write(bucket=INFLUX_BUCKET, org=INFLUX_ORG, record=point)
        client.close()
        
        return True
    
    except Exception as e:
        print(f"保存到InfluxDB时出错: {e}")
        return False
