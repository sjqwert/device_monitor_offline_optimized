import json
import threading
import time
from datetime import datetime

import paho.mqtt.client as mqtt
from src.models.device import Device, db
from src.services.influxdb_service import save_to_influxdb

# MQTT配置
MQTT_BROKER = "localhost"
MQTT_PORT = 1883
MQTT_TOPIC = "devices/+/data"
MQTT_CLIENT_ID = "device_monitor_backend"

# 全局变量，存储最新设备状态
device_status = {}
# 线程锁，用于保护device_status的并发访问
status_lock = threading.Lock()
# 回调函数列表，用于通知WebSocket服务
callbacks = []

def on_connect(client, userdata, flags, rc):
    """连接MQTT Broker后的回调函数"""
    print(f"已连接到MQTT Broker，返回码: {rc}")
    # 订阅主题
    client.subscribe(MQTT_TOPIC)
    print(f"已订阅主题: {MQTT_TOPIC}")

def on_message(client, userdata, msg):
    """接收到MQTT消息后的回调函数"""
    try:
        # 解析主题，获取设备ID
        topic_parts = msg.topic.split('/')
        if len(topic_parts) != 3:
            print(f"无效的主题格式: {msg.topic}")
            return
        
        device_id = topic_parts[1]
        
        # 解析消息内容
        payload = json.loads(msg.payload.decode('utf-8'))
        
        # 检查必要字段
        if 'ip_address' not in payload:
            print("消息缺少ip_address字段")
            return
        
        ip_address = payload['ip_address']
        timestamp = payload.get('timestamp', datetime.utcnow().isoformat())
        params = payload.get('params', {})
        
        # 存储到InfluxDB
        save_to_influxdb(ip_address, params, timestamp)
        
        # 更新PostgreSQL中的设备最后在线时间
        update_device_last_seen(ip_address)
        
        # 检查告警条件
        alerts = check_alerts(ip_address, params)
        
        # 更新设备状态缓存
        with status_lock:
            device_status[ip_address] = {
                'device_id': device_id,
                'ip_address': ip_address,
                'timestamp': timestamp,
                'params': params,
                'alerts': alerts
            }
        
        # 通知所有回调函数
        notify_callbacks(ip_address)
        
    except json.JSONDecodeError:
        print(f"无效的JSON格式: {msg.payload}")
    except Exception as e:
        print(f"处理消息时出错: {e}")

def update_device_last_seen(ip_address):
    """更新PostgreSQL中设备的最后在线时间"""
    try:
        # 查找设备
        device = Device.query.filter_by(ip_address=ip_address).first()
        
        # 如果设备存在，更新最后在线时间
        if device:
            device.update_last_seen()
        else:
            # 如果设备不存在，创建新设备
            device = Device(
                ip_address=ip_address,
                name=f"设备 {ip_address}"
            )
            db.session.add(device)
        
        db.session.commit()
        
    except Exception as e:
        print(f"更新设备最后在线时间时出错: {e}")
        db.session.rollback()

def check_alerts(ip_address, params):
    """检查设备参数是否超过阈值，触发告警"""
    alerts = []
    try:
        # 查找设备
        device = Device.query.filter_by(ip_address=ip_address).first()
        
        if device and device.status_thresholds:
            thresholds = device.status_thresholds
            
            # 检查每个参数是否超过阈值
            for param, value in params.items():
                # 检查最大值
                max_key = f"{param}_max"
                if max_key in thresholds and isinstance(value, (int, float)):
                    max_value = float(thresholds[max_key])
                    if value > max_value:
                        alerts.append({
                            "type": "alert",
                            "device_id": ip_address,
                            "param": param,
                            "value": value,
                            "threshold": max_value,
                            "message": f"{param}超过最大值: {value} > {max_value}"
                        })
                
                # 检查最小值
                min_key = f"{param}_min"
                if min_key in thresholds and isinstance(value, (int, float)):
                    min_value = float(thresholds[min_key])
                    if value < min_value:
                        alerts.append({
                            "type": "alert",
                            "device_id": ip_address,
                            "param": param,
                            "value": value,
                            "threshold": min_value,
                            "message": f"{param}低于最小值: {value} < {min_value}"
                        })
        
    except Exception as e:
        print(f"检查告警时出错: {e}")
    
    return alerts

def notify_callbacks(ip_address):
    """通知所有回调函数有新数据"""
    with status_lock:
        data = device_status.get(ip_address)
    
    if data:
        for callback in callbacks:
            try:
                callback(data)
            except Exception as e:
                print(f"通知回调函数时出错: {e}")

def register_callback(callback):
    """注册回调函数，用于通知WebSocket服务"""
    callbacks.append(callback)
    return len(callbacks) - 1

def unregister_callback(index):
    """注销回调函数"""
    if 0 <= index < len(callbacks):
        callbacks.pop(index)
        return True
    return False

def get_all_device_status():
    """获取所有设备的最新状态"""
    with status_lock:
        return device_status.copy()

def start_mqtt_client():
    """启动MQTT客户端"""
    client = mqtt.Client(client_id=MQTT_CLIENT_ID)
    client.on_connect = on_connect
    client.on_message = on_message
    
    try:
        client.connect(MQTT_BROKER, MQTT_PORT, 60)
        # 启动MQTT客户端循环
        client.loop_start()
        print(f"MQTT客户端已启动，连接到 {MQTT_BROKER}:{MQTT_PORT}")
        return client
    except Exception as e:
        print(f"启动MQTT客户端时出错: {e}")
        return None

def stop_mqtt_client(client):
    """停止MQTT客户端"""
    if client:
        client.loop_stop()
        client.disconnect()
        print("MQTT客户端已停止")

# MQTT客户端实例
mqtt_client = None

def init_mqtt_service(app):
    """初始化MQTT服务"""
    global mqtt_client
    
    with app.app_context():
        mqtt_client = start_mqtt_client()
    
    return mqtt_client
