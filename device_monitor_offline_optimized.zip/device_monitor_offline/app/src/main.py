import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify
from src.models.device import db, Device
from src.routes.api import api_bp
from src.routes.device_management import device_bp
import threading

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'device_monitor_secret_key'

# 注册API蓝图
app.register_blueprint(api_bp, url_prefix='/api')
# 注册设备管理蓝图
app.register_blueprint(device_bp, url_prefix='/api')

# 配置数据库
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///device_monitor.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# 初始化服务
mqtt_client = None
websocket_server = None

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

@app.route('/health')
def health_check():
    """健康检查接口"""
    return jsonify({"status": "ok", "message": "服务正常运行"})

def init_services():
    """初始化所有服务"""
    global mqtt_client, websocket_server
    
    with app.app_context():
        # 创建数据库表
        db.create_all()
        
        # 初始化MQTT服务
        from src.services.mqtt_service import init_mqtt_service
        mqtt_client = init_mqtt_service(app)
        
        # 初始化WebSocket服务
        from src.services.websocket_service import init_websocket_service
        websocket_server = init_websocket_service(app)

def start_device_simulator():
    """启动设备模拟器"""
    from src.device_simulator import start_simulator
    simulator_thread = threading.Thread(target=start_simulator)
    simulator_thread.daemon = True
    simulator_thread.start()
    return simulator_thread

if __name__ == '__main__':
    # 初始化服务
    init_services()
    
    # 启动设备模拟器
    simulator_thread = start_device_simulator()
    
    # 启动Flask应用
    app.run(host='0.0.0.0', port=5000, debug=True)
