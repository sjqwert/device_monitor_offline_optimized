// 全局变量
let websocket = null;
let currentDeviceId = null;
let devices = {};
let realtimeChart = null;
let historyChart = null;
let alertList = [];

// DOM元素
const loadingElement = document.getElementById('loading');
const deviceListElement = document.getElementById('device-list');
const paramsGridElement = document.getElementById('params-grid');
const currentDeviceInfoElement = document.getElementById('current-device-info');
const totalDevicesElement = document.getElementById('total-devices');
const onlineDevicesElement = document.getElementById('online-devices');
const alertDevicesElement = document.getElementById('alert-devices');
const alertListElement = document.getElementById('alert-list');
const fullscreenBtn = document.getElementById('fullscreen-btn');
const queryBtn = document.getElementById('query-btn');
const paramSelect = document.getElementById('param-select');
const timeRangeSelect = document.getElementById('time-range');

// 初始化函数
function init() {
    // 初始化ECharts
    initCharts();
    
    // 获取设备列表
    fetchDevices();
    
    // 连接WebSocket
    connectWebSocket();
    
    // 获取系统状态
    fetchSystemStatus();
    
    // 绑定事件
    bindEvents();
    
    // 定时刷新
    setInterval(fetchSystemStatus, 30000); // 每30秒刷新一次系统状态
}

// 初始化图表
function initCharts() {
    // 实时图表
    realtimeChart = echarts.init(document.getElementById('realtime-chart'));
    const realtimeOption = {
        title: {
            text: '实时趋势',
            textStyle: {
                color: '#aaa',
                fontSize: 14
            }
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross',
                label: {
                    backgroundColor: '#6a7985'
                }
            }
        },
        legend: {
            data: ['温度', '湿度', '电压', '电流'],
            textStyle: {
                color: '#aaa'
            }
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'time',
            boundaryGap: false,
            axisLine: {
                lineStyle: {
                    color: '#aaa'
                }
            }
        },
        yAxis: {
            type: 'value',
            axisLine: {
                lineStyle: {
                    color: '#aaa'
                }
            },
            splitLine: {
                lineStyle: {
                    color: '#263550'
                }
            }
        },
        series: [
            {
                name: '温度',
                type: 'line',
                smooth: true,
                symbol: 'none',
                sampling: 'average',
                itemStyle: {
                    color: '#ff9800'
                },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgba(255, 152, 0, 0.3)'
                        },
                        {
                            offset: 1,
                            color: 'rgba(255, 152, 0, 0)'
                        }
                    ])
                },
                data: []
            },
            {
                name: '湿度',
                type: 'line',
                smooth: true,
                symbol: 'none',
                sampling: 'average',
                itemStyle: {
                    color: '#2196f3'
                },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgba(33, 150, 243, 0.3)'
                        },
                        {
                            offset: 1,
                            color: 'rgba(33, 150, 243, 0)'
                        }
                    ])
                },
                data: []
            },
            {
                name: '电压',
                type: 'line',
                smooth: true,
                symbol: 'none',
                sampling: 'average',
                itemStyle: {
                    color: '#4caf50'
                },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgba(76, 175, 80, 0.3)'
                        },
                        {
                            offset: 1,
                            color: 'rgba(76, 175, 80, 0)'
                        }
                    ])
                },
                data: []
            },
            {
                name: '电流',
                type: 'line',
                smooth: true,
                symbol: 'none',
                sampling: 'average',
                itemStyle: {
                    color: '#9c27b0'
                },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgba(156, 39, 176, 0.3)'
                        },
                        {
                            offset: 1,
                            color: 'rgba(156, 39, 176, 0)'
                        }
                    ])
                },
                data: []
            }
        ]
    };
    realtimeChart.setOption(realtimeOption);
    
    // 历史图表
    historyChart = echarts.init(document.getElementById('history-chart'));
    const historyOption = {
        title: {
            text: '历史趋势',
            textStyle: {
                color: '#aaa',
                fontSize: 14
            }
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross',
                label: {
                    backgroundColor: '#6a7985'
                }
            }
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'time',
            boundaryGap: false,
            axisLine: {
                lineStyle: {
                    color: '#aaa'
                }
            }
        },
        yAxis: {
            type: 'value',
            axisLine: {
                lineStyle: {
                    color: '#aaa'
                }
            },
            splitLine: {
                lineStyle: {
                    color: '#263550'
                }
            }
        },
        series: [
            {
                name: '参数值',
                type: 'line',
                smooth: true,
                symbol: 'none',
                sampling: 'average',
                itemStyle: {
                    color: '#4fc3f7'
                },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgba(79, 195, 247, 0.3)'
                        },
                        {
                            offset: 1,
                            color: 'rgba(79, 195, 247, 0)'
                        }
                    ])
                },
                data: []
            }
        ]
    };
    historyChart.setOption(historyOption);
    
    // 窗口大小变化时重新调整图表大小
    window.addEventListener('resize', function() {
        realtimeChart.resize();
        historyChart.resize();
    });
}

// 获取设备列表
function fetchDevices() {
    fetch('/api/devices')
        .then(response => response.json())
        .then(data => {
            devices = {};
            data.devices.forEach(device => {
                devices[device.ip_address] = device;
            });
            renderDeviceList();
            hideLoading();
        })
        .catch(error => {
            console.error('获取设备列表失败:', error);
            hideLoading();
        });
}

// 渲染设备列表
function renderDeviceList() {
    if (Object.keys(devices).length === 0) {
        deviceListElement.innerHTML = '<li class="no-data">暂无设备数据</li>';
        return;
    }
    
    deviceListElement.innerHTML = '';
    Object.values(devices).forEach(device => {
        const hasAlerts = device.status && device.status.alerts && device.status.alerts.length > 0;
        const isOnline = device.online;
        
        let statusClass = 'status-offline';
        if (isOnline) {
            statusClass = hasAlerts ? 'status-alert' : 'status-online';
        }
        
        const deviceItem = document.createElement('li');
        deviceItem.className = `device-item ${device.ip_address === currentDeviceId ? 'active' : ''}`;
        deviceItem.dataset.id = device.ip_address;
        deviceItem.innerHTML = `
            <div class="device-name">${device.name}</div>
            <div class="device-ip">${device.ip_address}</div>
            <div class="device-status ${statusClass}"></div>
        `;
        deviceItem.addEventListener('click', () => selectDevice(device.ip_address));
        deviceListElement.appendChild(deviceItem);
    });
    
    // 如果当前没有选中设备，默认选中第一个
    if (!currentDeviceId && Object.keys(devices).length > 0) {
        selectDevice(Object.keys(devices)[0]);
    }
}

// 选择设备
function selectDevice(deviceId) {
    currentDeviceId = deviceId;
    
    // 更新设备列表选中状态
    document.querySelectorAll('.device-item').forEach(item => {
        item.classList.toggle('active', item.dataset.id === deviceId);
    });
    
    // 更新当前设备信息
    const device = devices[deviceId];
    if (device) {
        currentDeviceInfoElement.textContent = `${device.name} (${device.ip_address})`;
        
        // 渲染参数卡片
        renderParamsGrid(device);
        
        // 清空并重新初始化实时图表数据
        initRealtimeChartData(device);
        
        // 查询历史数据
        queryHistoryData();
    }
}

// 渲染参数卡片
function renderParamsGrid(device) {
    if (!device.status || !device.status.params) {
        paramsGridElement.innerHTML = '<div class="no-data">暂无参数数据</div>';
        return;
    }
    
    const params = device.status.params;
    paramsGridElement.innerHTML = '';
    
    // 定义参数单位
    const units = {
        temperature: '°C',
        humidity: '%',
        voltage: 'V',
        current: 'A',
        status_code: ''
    };
    
    // 定义参数中文名
    const paramNames = {
        temperature: '温度',
        humidity: '湿度',
        voltage: '电压',
        current: '电流',
        status_code: '状态码'
    };
    
    // 检查参数是否有告警
    const alerts = device.status.alerts || [];
    const alertParams = alerts.map(alert => alert.param);
    
    // 创建参数卡片
    Object.entries(params).forEach(([key, value]) => {
        const isAlert = alertParams.includes(key);
        const paramCard = document.createElement('div');
        paramCard.className = `param-card ${isAlert ? 'alert' : ''}`;
        
        const paramName = paramNames[key] || key;
        const unit = units[key] || '';
        
        paramCard.innerHTML = `
            <div class="param-name">${paramName}</div>
            <div class="param-value">${value}<span class="param-unit">${unit}</span></div>
        `;
        
        paramsGridElement.appendChild(paramCard);
    });
}

// 初始化实时图表数据
function initRealtimeChartData(device) {
    if (!device.status || !device.status.params) {
        return;
    }
    
    const params = device.status.params;
    const timestamp = device.status.timestamp;
    
    // 清空图表数据
    const option = realtimeChart.getOption();
    option.series.forEach(series => {
        series.data = [];
    });
    
    // 添加初始数据点
    if (params.temperature !== undefined) {
        option.series[0].data.push([timestamp, params.temperature]);
    }
    if (params.humidity !== undefined) {
        option.series[1].data.push([timestamp, params.humidity]);
    }
    if (params.voltage !== undefined) {
        option.series[2].data.push([timestamp, params.voltage]);
    }
    if (params.current !== undefined) {
        option.series[3].data.push([timestamp, params.current]);
    }
    
    realtimeChart.setOption(option);
}

// 更新实时图表数据
function updateRealtimeChartData(deviceId, data) {
    if (deviceId !== currentDeviceId || !data.params) {
        return;
    }
    
    const params = data.params;
    const timestamp = data.timestamp;
    
    // 更新图表数据
    const option = realtimeChart.getOption();
    
    // 添加新数据点
    if (params.temperature !== undefined) {
        option.series[0].data.push([timestamp, params.temperature]);
        // 保留最近30个数据点
        if (option.series[0].data.length > 30) {
            option.series[0].data.shift();
        }
    }
    if (params.humidity !== undefined) {
        option.series[1].data.push([timestamp, params.humidity]);
        if (option.series[1].data.length > 30) {
            option.series[1].data.shift();
        }
    }
    if (params.voltage !== undefined) {
        option.series[2].data.push([timestamp, params.voltage]);
        if (option.series[2].data.length > 30) {
            option.series[2].data.shift();
        }
    }
    if (params.current !== undefined) {
        option.series[3].data.push([timestamp, params.current]);
        if (option.series[3].data.length > 30) {
            option.series[3].data.shift();
        }
    }
    
    realtimeChart.setOption(option);
}

// 查询历史数据
function queryHistoryData() {
    if (!currentDeviceId) {
        return;
    }
    
    const param = paramSelect.value;
    const timeRange = timeRangeSelect.value;
    
    // 计算时间范围
    const endTime = new Date().toISOString();
    let startTime;
    
    switch (timeRange) {
        case '1h':
            startTime = new Date(Date.now() - 3600000).toISOString();
            break;
        case '6h':
            startTime = new Date(Date.now() - 21600000).toISOString();
            break;
        case '24h':
            startTime = new Date(Date.now() - 86400000).toISOString();
            break;
        case '7d':
            startTime = new Date(Date.now() - 604800000).toISOString();
            break;
        case '30d':
            startTime = new Date(Date.now() - 2592000000).toISOString();
            break;
        default:
            startTime = new Date(Date.now() - 86400000).toISOString();
    }
    
    // 显示加载动画
    showLoading();
    
    // 查询历史数据
    fetch(`/api/devices/${currentDeviceId}/history?param=${param}&start_time=${startTime}&end_time=${endTime}`)
        .then(response => response.json())
        .then(data => {
            updateHistoryChart(data);
            hideLoading();
        })
        .catch(error => {
            console.error('查询历史数据失败:', error);
            hideLoading();
        });
}

// 更新历史图表
function updateHistoryChart(data) {
    if (!data.data || data.data.length === 0) {
        historyChart.setOption({
            title: {
                text: `历史趋势 - 暂无数据`
            },
            series: [
                {
                    name: '参数值',
                    data: []
                }
            ]
        });
        return;
    }
    
    // 参数中文名
    const paramNames = {
        temperature: '温度',
        humidity: '湿度',
        voltage: '电压',
        current: '电流',
        status_code: '状态码'
    };
    
    // 参数单位
    const units = {
        temperature: '°C',
        humidity: '%',
        voltage: 'V',
        current: 'A',
        status_code: ''
    };
    
    const paramName = paramNames[data.param] || data.param;
    const unit = units[data.param] || '';
    
    // 格式化数据
    const chartData = data.data.map(item => [item.time, item.value]);
    
    // 更新图表
    historyChart.setOption({
        title: {
            text: `历史趋势 - ${paramName}${unit ? ` (${unit})` : ''}`
        },
        series: [
            {
                name: paramName,
                data: chartData
            }
        ]
    });
}

// 获取系统状态
function fetchSystemStatus() {
    fetch('/api/status')
        .then(response => response.json())
        .then(data => {
            updateSystemStatus(data);
        })
        .catch(error => {
            console.error('获取系统状态失败:', error);
        });
}

// 更新系统状态
function updateSystemStatus(data) {
    totalDevicesElement.textContent = data.total_devices;
    onlineDevicesElement.textContent = data.online_devices;
    alertDevicesElement.textContent = data.alert_devices;
}

// 连接WebSocket
function connectWebSocket() {
    // 获取当前主机和端口
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.hostname;
    const port = window.location.port;
    
    // 创建WebSocket连接
    websocket = new WebSocket(`${protocol}//${host}:${port}/ws/dashboard`);
    
    // 连接打开
    websocket.onopen = function(event) {
        console.log('WebSocket连接已建立');
    };
    
    // 接收消息
    websocket.onmessage = function(event) {
        const data = JSON.parse(event.data);
        
        // 处理初始化数据
        if (data.type === 'init') {
            data.data.forEach(deviceData => {
                updateDeviceStatus(deviceData);
            });
            return;
        }
        
        // 处理设备数据更新
        updateDeviceStatus(data);
        
        // 处理告警
        if (data.alerts && data.alerts.length > 0) {
            data.alerts.forEach(alert => {
                addAlert(alert);
            });
        }
    };
    
    // 连接关闭
    websocket.onclose = function(event) {
        console.log('WebSocket连接已关闭');
        // 尝试重新连接
        setTimeout(connectWebSocket, 5000);
    };
    
    // 连接错误
    websocket.onerror = function(error) {
        console.error('WebSocket错误:', error);
    };
}

// 更新设备状态
function updateDeviceStatus(data) {
    const deviceId = data.ip_address;
    
    // 更新设备状态
    if (devices[deviceId]) {
        devices[deviceId].status = data;
        devices[deviceId].online = true;
        
        // 如果是当前选中的设备，更新参数卡片和实时图表
        if (deviceId === currentDeviceId) {
            renderParamsGrid(devices[deviceId]);
            updateRealtimeChartData(deviceId, data);
        }
    }
    
    // 更新设备列表
    renderDeviceList();
}

// 添加告警
function addAlert(alert) {
    // 添加时间戳
    alert.timestamp = new Date().toISOString();
    
    // 添加到告警列表
    alertList.unshift(alert);
    
    // 限制告警列表长度
    if (alertList.length > 100) {
        alertList.pop();
    }
    
    // 渲染告警列表
    renderAlertList();
}

// 渲染告警列表
function renderAlertList() {
    if (alertList.length === 0) {
        alertListElement.innerHTML = '<li class="no-data">暂无告警信息</li>';
        return;
    }
    
    alertListElement.innerHTML = '';
    alertList.forEach(alert => {
        const alertItem = document.createElement('li');
        alertItem.className = 'alert-item';
        
        // 格式化时间
        const timestamp = new Date(alert.timestamp);
        const formattedTime = timestamp.toLocaleString();
        
        // 获取设备名称
        const deviceName = devices[alert.device_id] ? devices[alert.device_id].name : alert.device_id;
        
        alertItem.innerHTML = `
            <div class="alert-header">
                <div class="alert-device">${deviceName}</div>
                <div class="alert-time">${formattedTime}</div>
            </div>
            <div class="alert-message">${alert.message}</div>
        `;
        
        alertListElement.appendChild(alertItem);
    });
}

// 绑定事件
function bindEvents() {
    // 全屏按钮
    fullscreenBtn.addEventListener('click', toggleFullscreen);
    
    // 查询按钮
    queryBtn.addEventListener('click', queryHistoryData);
    
    // 参数选择和时间范围变化时自动查询
    paramSelect.addEventListener('change', queryHistoryData);
    timeRangeSelect.addEventListener('change', queryHistoryData);
}

// 切换全屏
function toggleFullscreen() {
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(err => {
            console.error(`全屏请求失败: ${err.message}`);
        });
        fullscreenBtn.textContent = '退出全屏';
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen();
            fullscreenBtn.textContent = '全屏显示';
        }
    }
}

// 显示加载动画
function showLoading() {
    loadingElement.style.display = 'flex';
}

// 隐藏加载动画
function hideLoading() {
    loadingElement.style.display = 'none';
}

// 页面加载完成后初始化
window.addEventListener('load', init);
