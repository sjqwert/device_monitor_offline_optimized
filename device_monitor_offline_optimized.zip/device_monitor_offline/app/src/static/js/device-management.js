// 设备管理功能
let deviceManagementInitialized = false;

// 初始化设备管理功能
function initDeviceManagement() {
    if (deviceManagementInitialized) return;
    
    // 添加设备管理CSS
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'css/device-management.css';
    document.head.appendChild(link);
    
    // 创建设备管理标签页
    createDeviceManagementTab();
    
    // 创建设备管理UI
    createDeviceManagementUI();
    
    // 创建通知组件
    createNotificationComponent();
    
    // 创建确认对话框
    createConfirmDialog();
    
    // 加载设备列表
    loadDeviceList();
    
    deviceManagementInitialized = true;
}

// 创建设备管理标签页
function createDeviceManagementTab() {
    // 创建标签容器
    const tabsContainer = document.createElement('div');
    tabsContainer.className = 'tabs';
    tabsContainer.innerHTML = `
        <div class="tab active" data-tab="dashboard">监控大屏</div>
        <div class="tab" data-tab="device-management">设备管理</div>
    `;
    
    // 创建内容容器
    const dashboardContent = document.createElement('div');
    dashboardContent.className = 'tab-content active';
    dashboardContent.id = 'dashboard-content';
    
    const deviceManagementContent = document.createElement('div');
    deviceManagementContent.className = 'tab-content';
    deviceManagementContent.id = 'device-management-content';
    
    // 获取原始内容
    const dashboardElement = document.querySelector('.dashboard');
    
    // 重组DOM
    const mainElement = document.querySelector('.main');
    mainElement.innerHTML = '';
    mainElement.appendChild(tabsContainer);
    mainElement.appendChild(dashboardContent);
    mainElement.appendChild(deviceManagementContent);
    
    // 将原始内容移动到dashboard标签页
    dashboardContent.appendChild(dashboardElement);
    
    // 绑定标签切换事件
    tabsContainer.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            // 更新标签状态
            tabsContainer.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // 更新内容状态
            const tabId = tab.dataset.tab;
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            document.getElementById(`${tabId}-content`).classList.add('active');
        });
    });
}

// 创建设备管理UI
function createDeviceManagementUI() {
    const deviceManagementContent = document.getElementById('device-management-content');
    
    // 创建设备管理面板
    const deviceManagement = document.createElement('div');
    deviceManagement.className = 'device-management';
    deviceManagement.innerHTML = `
        <div class="device-management-header">
            <h2 class="device-management-title">设备管理</h2>
        </div>
        
        <form id="device-form" class="device-form">
            <div class="device-form-group">
                <label for="device-ip">设备IP地址</label>
                <input type="text" id="device-ip" placeholder="例如: 192.168.1.100" required>
            </div>
            <div class="device-form-group">
                <label for="device-name">设备名称</label>
                <input type="text" id="device-name" placeholder="例如: 服务器A" required>
            </div>
            <div class="device-form-group">
                <label for="device-location">设备位置</label>
                <input type="text" id="device-location" placeholder="例如: 机房1">
            </div>
            <div class="device-form-group">
                <label for="device-type">设备类型</label>
                <input type="text" id="device-type" placeholder="例如: 服务器">
            </div>
            <div class="device-form-actions">
                <button type="submit" id="add-device-btn">添加设备</button>
                <button type="button" id="reset-form-btn" class="cancel">重置</button>
            </div>
        </form>
        
        <table class="device-table">
            <thead>
                <tr>
                    <th>IP地址</th>
                    <th>设备名称</th>
                    <th>位置</th>
                    <th>类型</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody id="device-list-body">
                <tr>
                    <td colspan="6" class="no-data">加载设备列表中...</td>
                </tr>
            </tbody>
        </table>
    `;
    
    deviceManagementContent.appendChild(deviceManagement);
    
    // 绑定表单提交事件
    const deviceForm = document.getElementById('device-form');
    deviceForm.addEventListener('submit', (e) => {
        e.preventDefault();
        addDevice();
    });
    
    // 绑定重置按钮事件
    const resetFormBtn = document.getElementById('reset-form-btn');
    resetFormBtn.addEventListener('click', () => {
        deviceForm.reset();
    });
}

// 创建通知组件
function createNotificationComponent() {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.id = 'notification';
    document.body.appendChild(notification);
}

// 显示通知
function showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = `notification ${type}`;
    
    // 显示通知
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // 自动隐藏
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

// 创建确认对话框
function createConfirmDialog() {
    const dialog = document.createElement('div');
    dialog.className = 'confirm-dialog';
    dialog.id = 'confirm-dialog';
    dialog.innerHTML = `
        <div class="confirm-dialog-content">
            <div class="confirm-dialog-title">确认操作</div>
            <div class="confirm-dialog-message" id="confirm-dialog-message"></div>
            <div class="confirm-dialog-actions">
                <button class="cancel" id="confirm-dialog-cancel">取消</button>
                <button class="confirm" id="confirm-dialog-confirm">确认</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(dialog);
    
    // 绑定取消按钮事件
    const cancelBtn = document.getElementById('confirm-dialog-cancel');
    cancelBtn.addEventListener('click', () => {
        hideConfirmDialog();
    });
}

// 显示确认对话框
function showConfirmDialog(message, confirmCallback) {
    const dialog = document.getElementById('confirm-dialog');
    const messageElement = document.getElementById('confirm-dialog-message');
    const confirmBtn = document.getElementById('confirm-dialog-confirm');
    
    // 设置消息
    messageElement.textContent = message;
    
    // 绑定确认按钮事件
    confirmBtn.onclick = () => {
        hideConfirmDialog();
        confirmCallback();
    };
    
    // 显示对话框
    dialog.classList.add('show');
}

// 隐藏确认对话框
function hideConfirmDialog() {
    const dialog = document.getElementById('confirm-dialog');
    dialog.classList.remove('show');
}

// 加载设备列表
function loadDeviceList() {
    fetch('/api/devices')
        .then(response => response.json())
        .then(data => {
            renderDeviceList(data.devices);
        })
        .catch(error => {
            console.error('获取设备列表失败:', error);
            showNotification('获取设备列表失败，请刷新页面重试', 'error');
        });
}

// 渲染设备列表
function renderDeviceList(devices) {
    const deviceListBody = document.getElementById('device-list-body');
    
    if (!devices || devices.length === 0) {
        deviceListBody.innerHTML = '<tr><td colspan="6" class="no-data">暂无设备数据</td></tr>';
        return;
    }
    
    deviceListBody.innerHTML = '';
    devices.forEach(device => {
        const isOnline = device.online;
        const hasAlerts = device.status && device.status.alerts && device.status.alerts.length > 0;
        
        let statusText = '离线';
        let statusClass = 'status-offline';
        
        if (isOnline) {
            statusText = hasAlerts ? '告警' : '正常';
            statusClass = hasAlerts ? 'status-alert' : 'status-online';
        }
        
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${device.ip_address}</td>
            <td>${device.name}</td>
            <td>${device.location || '-'}</td>
            <td>${device.type || '-'}</td>
            <td><span class="${statusClass}">${statusText}</span></td>
            <td class="device-actions">
                <button class="delete" data-ip="${device.ip_address}">删除</button>
            </td>
        `;
        
        deviceListBody.appendChild(tr);
    });
    
    // 绑定删除按钮事件
    deviceListBody.querySelectorAll('.device-actions .delete').forEach(btn => {
        btn.addEventListener('click', () => {
            const ip = btn.dataset.ip;
            showConfirmDialog(`确定要删除设备 ${ip} 吗？此操作不可撤销。`, () => {
                removeDevice(ip);
            });
        });
    });
}

// 添加设备
function addDevice() {
    const ipInput = document.getElementById('device-ip');
    const nameInput = document.getElementById('device-name');
    const locationInput = document.getElementById('device-location');
    const typeInput = document.getElementById('device-type');
    
    const ip = ipInput.value.trim();
    const name = nameInput.value.trim();
    const location = locationInput.value.trim();
    const type = typeInput.value.trim();
    
    // 验证IP地址格式
    const ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
    if (!ipPattern.test(ip)) {
        showNotification('IP地址格式无效，请输入有效的IPv4地址', 'error');
        return;
    }
    
    // 验证IP地址范围
    const ipParts = ip.split('.');
    for (const part of ipParts) {
        const num = parseInt(part, 10);
        if (num < 0 || num > 255) {
            showNotification('IP地址格式无效，每个部分必须在0-255之间', 'error');
            return;
        }
    }
    
    // 构建设备数据
    const deviceData = {
        ip_address: ip,
        name: name,
        location: location,
        type: type
    };
    
    // 发送请求
    fetch('/api/devices', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(deviceData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            showNotification(data.error, 'error');
        } else {
            showNotification('设备添加成功', 'success');
            document.getElementById('device-form').reset();
            loadDeviceList();
        }
    })
    .catch(error => {
        console.error('添加设备失败:', error);
        showNotification('添加设备失败，请重试', 'error');
    });
}

// 删除设备
function removeDevice(ip) {
    fetch(`/api/devices/${ip}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            showNotification(data.error, 'error');
        } else {
            showNotification('设备删除成功', 'success');
            loadDeviceList();
        }
    })
    .catch(error => {
        console.error('删除设备失败:', error);
        showNotification('删除设备失败，请重试', 'error');
    });
}

// 在页面加载完成后初始化设备管理功能
document.addEventListener('DOMContentLoaded', () => {
    // 等待主应用初始化完成
    setTimeout(() => {
        initDeviceManagement();
    }, 1000);
});
