from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Device(db.Model):
    """设备模型"""
    __tablename__ = 'devices'
    
    id = db.Column(db.Integer, primary_key=True)
    ip_address = db.Column(db.String(15), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(100))
    type = db.Column(db.String(50))
    status_thresholds = db.Column(db.JSON)
    last_seen_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, ip_address, name, location=None, type=None, status_thresholds=None):
        self.ip_address = ip_address
        self.name = name
        self.location = location
        self.type = type
        self.status_thresholds = status_thresholds or {}
        self.created_at = datetime.utcnow()
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'ip_address': self.ip_address,
            'name': self.name,
            'location': self.location,
            'type': self.type,
            'status_thresholds': self.status_thresholds,
            'last_seen_at': self.last_seen_at.isoformat() if self.last_seen_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def update_last_seen(self):
        """更新最后在线时间"""
        self.last_seen_at = datetime.utcnow()
