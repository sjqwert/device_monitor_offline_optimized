#!/usr/bin/env python3
"""
设备模拟器
用于模拟设备发送数据到MQTT Broker
"""
import json
import random
import time
import threading
from datetime import datetime

import paho.mqtt.client as mqtt

# MQTT配置
MQTT_BROKER = "localhost"
MQTT_PORT = 1883
MQTT_CLIENT_ID = "device_simulator"

# 模拟设备列表
DEVICES = [
    {"device_id": "device1", "ip_address": "192.168.1.100", "name": "服务器A"},
    {"device_id": "device2", "ip_address": "192.168.1.101", "name": "服务器B"},
    {"device_id": "device3", "ip_address": "192.168.1.102", "name": "网络交换机"},
    {"device_id": "device4", "ip_address": "192.168.1.103", "name": "存储设备"},
    {"device_id": "device5", "ip_address": "192.168.1.104", "name": "UPS电源"}
]

# 基础参数值
BASE_VALUES = {
    "192.168.1.100": {"temperature": 35, "humidity": 50, "voltage": 220, "current": 5, "status_code": 0},
    "192.168.1.101": {"temperature": 32, "humidity": 55, "voltage": 220, "current": 4.5, "status_code": 0},
    "192.168.1.102": {"temperature": 30, "humidity": 45, "voltage": 220, "current": 2, "status_code": 0},
    "192.168.1.103": {"temperature": 28, "humidity": 60, "voltage": 220, "current": 3, "status_code": 0},
    "192.168.1.104": {"temperature": 40, "humidity": 40, "voltage": 220, "current": 8, "status_code": 0}
}

# 全局变量
mqtt_client = None
running = False
threads = []

def on_connect(client, userdata, flags, rc):
    """连接MQTT Broker后的回调函数"""
    print(f"已连接到MQTT Broker，返回码: {rc}")

def generate_device_data(device):
    """生成设备数据"""
    device_id = device["device_id"]
    ip_address = device["ip_address"]
    base = BASE_VALUES[ip_address]
    
    # 添加随机波动
    params = {
        "temperature": round(base["temperature"] + random.uniform(-2, 2), 1),
        "humidity": round(base["humidity"] + random.uniform(-5, 5), 1),
        "voltage": round(base["voltage"] + random.uniform(-5, 5), 1),
        "current": round(base["current"] + random.uniform(-0.5, 0.5), 2),
        "status_code": base["status_code"]
    }
    
    # 随机生成告警状态
    if random.random() < 0.05:  # 5%的概率生成告警
        if random.random() < 0.5:
            params["temperature"] = round(base["temperature"] + random.uniform(15, 20), 1)  # 温度过高
        else:
            params["voltage"] = round(base["voltage"] + random.uniform(-30, -20), 1)  # 电压过低
    
    # 构建消息
    message = {
        "device_id": device_id,
        "ip_address": ip_address,
        "timestamp": datetime.utcnow().isoformat(),
        "params": params
    }
    
    return message

def device_thread(device):
    """设备线程，定期发送数据"""
    global running
    
    device_id = device["device_id"]
    topic = f"devices/{device_id}/data"
    
    print(f"设备 {device_id} 线程已启动")
    
    while running:
        try:
            # 生成数据
            message = generate_device_data(device)
            
            # 发送数据
            mqtt_client.publish(topic, json.dumps(message))
            print(f"设备 {device_id} 已发送数据: {message}")
            
            # 随机等待5-10秒
            wait_time = random.uniform(5, 10)
            time.sleep(wait_time)
            
        except Exception as e:
            print(f"设备 {device_id} 发送数据时出错: {e}")
            time.sleep(5)  # 出错后等待5秒再重试

def start_simulator():
    """启动模拟器"""
    global mqtt_client, running, threads
    
    # 创建MQTT客户端
    mqtt_client = mqtt.Client(client_id=MQTT_CLIENT_ID)
    mqtt_client.on_connect = on_connect
    
    try:
        # 连接MQTT Broker
        mqtt_client.connect(MQTT_BROKER, MQTT_PORT, 60)
        mqtt_client.loop_start()
        
        # 设置运行标志
        running = True
        
        # 为每个设备创建线程
        threads = []
        for device in DEVICES:
            thread = threading.Thread(target=device_thread, args=(device,))
            thread.daemon = True
            thread.start()
            threads.append(thread)
        
        print(f"模拟器已启动，模拟 {len(DEVICES)} 个设备")
        
        # 等待用户中断
        try:
            while running:
                time.sleep(1)
        except KeyboardInterrupt:
            stop_simulator()
        
    except Exception as e:
        print(f"启动模拟器时出错: {e}")
        stop_simulator()

def stop_simulator():
    """停止模拟器"""
    global mqtt_client, running
    
    # 设置停止标志
    running = False
    
    # 等待所有线程结束
    for thread in threads:
        thread.join(timeout=2)
    
    # 停止MQTT客户端
    if mqtt_client:
        mqtt_client.loop_stop()
        mqtt_client.disconnect()
    
    print("模拟器已停止")

if __name__ == "__main__":
    start_simulator()
