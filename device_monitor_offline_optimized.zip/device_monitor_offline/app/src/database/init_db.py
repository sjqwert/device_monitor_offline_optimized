#!/usr/bin/env python3
"""
数据库初始化脚本
用于初始化PostgreSQL和InfluxDB
"""
import sys
import os
import json
from datetime import datetime, timedelta
import random

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.models.device import Device, db
from src.services.influxdb_service import save_to_influxdb
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS

# InfluxDB配置
INFLUX_URL = "http://localhost:8086"
INFLUX_TOKEN = "my-token"
INFLUX_ORG = "my-org"
INFLUX_BUCKET = "device_data"

def init_postgresql(app):
    """初始化PostgreSQL数据库"""
    print("正在初始化PostgreSQL数据库...")
    
    with app.app_context():
        # 创建表
        db.create_all()
        
        # 检查是否已有设备数据
        if Device.query.count() > 0:
            print("数据库中已有设备数据，跳过初始化")
            return
        
        # 创建示例设备
        devices = [
            Device(
                ip_address="192.168.1.100",
                name="服务器A",
                location="机房1",
                type="服务器",
                status_thresholds={
                    "temperature_max": 50,
                    "temperature_min": 10,
                    "humidity_max": 80,
                    "humidity_min": 20,
                    "voltage_max": 240,
                    "voltage_min": 200,
                    "current_max": 10
                }
            ),
            Device(
                ip_address="192.168.1.101",
                name="服务器B",
                location="机房1",
                type="服务器",
                status_thresholds={
                    "temperature_max": 50,
                    "temperature_min": 10,
                    "humidity_max": 80,
                    "humidity_min": 20,
                    "voltage_max": 240,
                    "voltage_min": 200,
                    "current_max": 10
                }
            ),
            Device(
                ip_address="192.168.1.102",
                name="网络交换机",
                location="机房2",
                type="网络设备",
                status_thresholds={
                    "temperature_max": 45,
                    "temperature_min": 5,
                    "voltage_max": 240,
                    "voltage_min": 200
                }
            ),
            Device(
                ip_address="192.168.1.103",
                name="存储设备",
                location="机房2",
                type="存储",
                status_thresholds={
                    "temperature_max": 40,
                    "temperature_min": 5,
                    "humidity_max": 70,
                    "humidity_min": 30,
                    "voltage_max": 240,
                    "voltage_min": 200
                }
            ),
            Device(
                ip_address="192.168.1.104",
                name="UPS电源",
                location="机房1",
                type="电源设备",
                status_thresholds={
                    "temperature_max": 60,
                    "voltage_max": 250,
                    "voltage_min": 190,
                    "current_max": 20
                }
            )
        ]
        
        # 添加设备到数据库
        for device in devices:
            db.session.add(device)
        
        # 提交事务
        db.session.commit()
        
        print(f"已创建 {len(devices)} 个示例设备")

def init_influxdb():
    """初始化InfluxDB数据库"""
    print("正在初始化InfluxDB数据库...")
    
    try:
        # 连接InfluxDB
        client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
        
        # 检查bucket是否存在
        buckets_api = client.buckets_api()
        bucket_list = buckets_api.find_buckets().buckets
        bucket_names = [bucket.name for bucket in bucket_list]
        
        if INFLUX_BUCKET not in bucket_names:
            print(f"创建bucket: {INFLUX_BUCKET}")
            buckets_api.create_bucket(bucket_name=INFLUX_BUCKET, org=INFLUX_ORG)
        
        # 生成历史数据
        generate_history_data(client)
        
        client.close()
        print("InfluxDB初始化完成")
        
    except Exception as e:
        print(f"初始化InfluxDB时出错: {e}")

def generate_history_data(client):
    """生成历史数据"""
    print("正在生成历史数据...")
    
    # 获取设备列表
    devices = [
        {"ip_address": "192.168.1.100", "name": "服务器A"},
        {"ip_address": "192.168.1.101", "name": "服务器B"},
        {"ip_address": "192.168.1.102", "name": "网络交换机"},
        {"ip_address": "192.168.1.103", "name": "存储设备"},
        {"ip_address": "192.168.1.104", "name": "UPS电源"}
    ]
    
    # 生成过去24小时的数据
    end_time = datetime.utcnow()
    start_time = end_time - timedelta(hours=24)
    
    # 每5分钟一个数据点
    interval = timedelta(minutes=5)
    current_time = start_time
    
    # 创建写入API
    write_api = client.write_api(write_options=SYNCHRONOUS)
    
    # 基础参数值
    base_values = {
        "192.168.1.100": {"temperature": 35, "humidity": 50, "voltage": 220, "current": 5, "status_code": 0},
        "192.168.1.101": {"temperature": 32, "humidity": 55, "voltage": 220, "current": 4.5, "status_code": 0},
        "192.168.1.102": {"temperature": 30, "humidity": 45, "voltage": 220, "current": 2, "status_code": 0},
        "192.168.1.103": {"temperature": 28, "humidity": 60, "voltage": 220, "current": 3, "status_code": 0},
        "192.168.1.104": {"temperature": 40, "humidity": 40, "voltage": 220, "current": 8, "status_code": 0}
    }
    
    # 生成数据点
    points = []
    while current_time < end_time:
        for device in devices:
            ip_address = device["ip_address"]
            base = base_values[ip_address]
            
            # 添加随机波动
            params = {
                "temperature": base["temperature"] + random.uniform(-2, 2),
                "humidity": base["humidity"] + random.uniform(-5, 5),
                "voltage": base["voltage"] + random.uniform(-5, 5),
                "current": base["current"] + random.uniform(-0.5, 0.5),
                "status_code": base["status_code"]
            }
            
            # 创建数据点
            point = Point("device_data") \
                .tag("ip_address", ip_address) \
                .time(current_time)
            
            # 添加字段
            for key, value in params.items():
                if isinstance(value, (int, float)):
                    point = point.field(key, value)
            
            points.append(point)
        
        current_time += interval
    
    # 批量写入数据
    write_api.write(bucket=INFLUX_BUCKET, org=INFLUX_ORG, record=points)
    
    print(f"已生成 {len(points)} 个历史数据点")

def main():
    """主函数"""
    # 导入Flask应用
    from src.main import app
    
    # 初始化PostgreSQL
    init_postgresql(app)
    
    # 初始化InfluxDB
    init_influxdb()
    
    print("数据库初始化完成")

if __name__ == "__main__":
    main()
