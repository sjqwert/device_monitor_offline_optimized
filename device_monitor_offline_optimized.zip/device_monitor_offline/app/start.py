#!/usr/bin/env python3
"""
启动脚本
用于一键启动所有服务
"""
import os
import sys
import subprocess
import time
import threading
import webbrowser
import signal
import atexit

def check_dependencies():
    """检查依赖是否已安装"""
    required_packages = [
        "flask", "paho-mqtt", "influxdb-client", "websockets"
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package.replace("-", "_"))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print("缺少以下依赖包，正在安装...")
        for package in missing_packages:
            print(f"安装 {package}...")
            subprocess.run([sys.executable, "-m", "pip", "install", package], check=True)
        print("所有依赖包已安装")

def start_influxdb():
    """启动InfluxDB服务"""
    print("正在启动InfluxDB服务...")
    try:
        # 检查InfluxDB是否已安装
        influxdb_path = "influxd"
        
        # 启动InfluxDB
        process = subprocess.Popen(
            [influxdb_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        # 等待启动
        time.sleep(3)
        
        # 检查进程是否存活
        if process.poll() is None:
            print("InfluxDB服务已启动")
            return process
        else:
            stdout, stderr = process.communicate()
            print(f"启动InfluxDB失败: {stderr}")
            print("将使用SQLite作为替代存储")
            return None
    except Exception as e:
        print(f"启动InfluxDB时出错: {e}")
        print("将使用SQLite作为替代存储")
        return None

def start_mosquitto():
    """启动Mosquitto MQTT Broker"""
    print("正在启动Mosquitto MQTT Broker...")
    try:
        # 检查Mosquitto是否已安装
        mosquitto_path = "mosquitto"
        
        # 启动Mosquitto
        process = subprocess.Popen(
            [mosquitto_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        # 等待启动
        time.sleep(2)
        
        # 检查进程是否存活
        if process.poll() is None:
            print("Mosquitto MQTT Broker已启动")
            return process
        else:
            stdout, stderr = process.communicate()
            print(f"启动Mosquitto失败: {stderr}")
            return None
    except Exception as e:
        print(f"启动Mosquitto时出错: {e}")
        print("请确保已安装Mosquitto MQTT Broker")
        return None

def init_database():
    """初始化数据库"""
    print("正在初始化数据库...")
    try:
        # 获取数据库初始化脚本路径
        script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src", "database", "init_db.py")
        
        # 执行初始化脚本
        subprocess.run(
            [sys.executable, script_path],
            check=True
        )
        
        print("数据库初始化完成")
        return True
    except Exception as e:
        print(f"初始化数据库时出错: {e}")
        return False

def start_web_app():
    """启动Web应用"""
    print("正在启动Web应用...")
    try:
        # 获取主程序路径
        main_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src", "main.py")
        
        # 启动Web应用
        process = subprocess.Popen(
            [sys.executable, main_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        # 等待启动
        time.sleep(3)
        
        # 检查进程是否存活
        if process.poll() is None:
            print("Web应用已启动")
            return process
        else:
            stdout, stderr = process.communicate()
            print(f"启动Web应用失败: {stderr}")
            return None
    except Exception as e:
        print(f"启动Web应用时出错: {e}")
        return None

def monitor_process(process, name):
    """监控进程输出"""
    if process is None:
        return
    
    while True:
        line = process.stdout.readline()
        if not line and process.poll() is not None:
            break
        if line:
            print(f"[{name}] {line.strip()}")
    
    # 进程结束
    stdout, stderr = process.communicate()
    if stderr:
        print(f"[{name}] 错误: {stderr}")
    
    print(f"[{name}] 进程已结束")

def open_browser():
    """打开浏览器访问Web应用"""
    print("正在打开浏览器...")
    url = "http://localhost:5000"
    webbrowser.open(url)
    print(f"已打开浏览器访问: {url}")

def cleanup(processes):
    """清理所有进程"""
    print("\n正在关闭所有服务...")
    
    for name, process in processes.items():
        if process and process.poll() is None:
            print(f"关闭 {name}...")
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
    
    print("所有服务已关闭")

def handle_signal(sig, frame, processes):
    """处理信号"""
    cleanup(processes)
    sys.exit(0)

def main():
    """主函数"""
    print("=== 局域网设备智能监控可视化大屏 ===")
    print("正在启动系统...")
    
    # 检查依赖
    check_dependencies()
    
    # 启动服务
    processes = {}
    
    # 启动InfluxDB
    processes["InfluxDB"] = start_influxdb()
    
    # 启动Mosquitto
    processes["Mosquitto"] = start_mosquitto()
    
    # 初始化数据库
    init_database()
    
    # 启动Web应用
    processes["Web应用"] = start_web_app()
    if processes["Web应用"] is None:
        print("启动Web应用失败，系统退出")
        cleanup(processes)
        return
    
    # 注册信号处理
    signal.signal(signal.SIGINT, lambda sig, frame: handle_signal(sig, frame, processes))
    signal.signal(signal.SIGTERM, lambda sig, frame: handle_signal(sig, frame, processes))
    atexit.register(lambda: cleanup(processes))
    
    # 创建监控线程
    for name, process in processes.items():
        if process:
            thread = threading.Thread(
                target=monitor_process,
                args=(process, name),
                daemon=True
            )
            thread.start()
    
    # 等待服务启动
    print("等待服务启动...")
    time.sleep(5)
    
    # 打开浏览器
    open_browser()
    
    print("\n系统已启动，按Ctrl+C退出")
    try:
        # 保持主线程运行
        while True:
            time.sleep(1)
            
            # 检查Web应用是否仍在运行
            if processes["Web应用"].poll() is not None:
                print("Web应用已停止，系统退出")
                break
    except KeyboardInterrupt:
        pass
    finally:
        cleanup(processes)

if __name__ == "__main__":
    main()
